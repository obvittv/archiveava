# leaks from kris's discord from 2017-2020 maybe 2021
